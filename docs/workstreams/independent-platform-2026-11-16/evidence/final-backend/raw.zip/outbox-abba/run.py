#!/usr/bin/env python3
"""Run precompiled PgBase history benchmarks in repeated A/B/B/A order."""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import statistics
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument("--before", required=True)
parser.add_argument("--after", required=True)
parser.add_argument("--before-commit", required=True)
parser.add_argument("--after-commit", required=True)
parser.add_argument("--output", required=True)
parser.add_argument("--cycles", type=int, default=2)
parser.add_argument("--iterations", type=int, default=1000)
args = parser.parse_args()
directory = Path(args.output)
directory.mkdir(parents=True, exist_ok=True)

def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def resource(path):
    try:
        return Path(path).read_text().strip()
    except OSError:
        return None

manifest = {
    "runtime_commits": {"A": args.before_commit, "B": args.after_commit},
    "binary_sha256": {"A": sha256(args.before), "B": sha256(args.after)},
    "platform": platform.platform(),
    "cpu_count": os.cpu_count(),
    "GOMAXPROCS": os.environ.get("GOMAXPROCS"),
    "cpu_max": resource("/sys/fs/cgroup/cpu.max"),
    "memory_max": resource("/sys/fs/cgroup/memory.max"),
    "workload": "closed-loop idle delivery poll; 100000 delivered events; fresh disposable database each repetition",
    "warmup": "VACUUM ANALYZE source/delivery tables, then 10 delivery polls",
    "sampling": "1000 measured polls per repetition; all nanosecond samples retained in raw log",
    "iterations": args.iterations,
    "runs": [],
}
environment = dict(os.environ)
environment["PGBASE_BENCH_SAMPLES"] = "1"
environment.pop("PGBASE_BENCH_EXPLAIN", None)
for index, variant in enumerate("ABBA" * args.cycles, 1):
    binary = args.before if variant == "A" else args.after
    name = f"{index:02d}-{variant}.log"
    command = [binary, "-test.run=^$", "-test.bench=^BenchmarkOutboxDeliveredHistory/delivered=100000$",
               f"-test.benchtime={args.iterations}x", "-test.count=1", "-test.v"]
    started_at = dt.datetime.now(dt.timezone.utc).isoformat()
    started = time.monotonic()
    with (directory / name).open("wb") as output:
        completed = subprocess.run(command, env=environment, stdout=output, stderr=subprocess.STDOUT)
    entry = {"index": index, "variant": variant, "log": name, "started_at": started_at,
             "elapsed_seconds": time.monotonic() - started, "returncode": completed.returncode,
             "sha256": sha256(directory / name)}
    content = (directory / name).read_text()
    matches = re.findall(r"latency_ns rows=100000 samples=\[([\d ]+)\]", content)
    samples = max(([int(value) for value in match.split()] for match in matches), key=len, default=[])
    if len(samples) == args.iterations:
        ordered = sorted(samples)
        entry["samples"] = len(samples)
        for percentile in (50, 95, 99):
            entry[f"p{percentile}_ms"] = ordered[(len(ordered) - 1) * percentile // 100] / 1e6
        entry["mean_ms"] = statistics.mean(samples) / 1e6
        entry["polls_per_second"] = len(samples) / (sum(samples) / 1e9)
    manifest["runs"].append(entry)
    (directory / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps(entry), flush=True)
    if completed.returncode or len(samples) != args.iterations:
        raise SystemExit("benchmark failed or raw samples missing; preserving all completed evidence")

# Confidence intervals describe repeated-run means, not independent requests.
# Four repetitions per variant are a limited shared-host experiment; raw runs
# remain the primary evidence. t(0.975, 3)=3.182446 applies to the default run.
summary = {}
for variant in "AB":
    runs = [run for run in manifest["runs"] if run["variant"] == variant]
    summary[variant] = {"repetitions": len(runs)}
    for metric in ("p50_ms", "p95_ms", "p99_ms", "polls_per_second"):
        values = [run[metric] for run in runs]
        result = {"mean": statistics.mean(values), "min": min(values), "max": max(values),
                  "standard_deviation": statistics.stdev(values)}
        if len(values) == 4:
            margin = 3.182446 * statistics.stdev(values) / len(values) ** 0.5
            result["repeat_mean_t95_interval"] = [statistics.mean(values) - margin, statistics.mean(values) + margin]
        summary[variant][metric] = result
manifest["summary"] = summary
(directory / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
