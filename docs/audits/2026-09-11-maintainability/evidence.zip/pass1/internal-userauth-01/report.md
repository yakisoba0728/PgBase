# Pass 1 — internal/userauth-01

Reviewed all 57 assigned fixed blobs (11055 lines) from 5cb721ff5590bf89b45ea9087d2ace0b74fe7127. Each coverage entry records the complete line interval.

## Findings

- **IUA-01 (P1, static):** Global OAuth setup accepts redirect URIs that bypass the hardened endpoint policy used by per-collection OAuth configuration.
- **IUA-02 (P2, static):** Direct privileged record email changes can preserve the verified flag without mailbox confirmation; route-level intent needs confirmation before implementation.
- **IUA-03 (P3, static):** Auth-rule validation and SQL resolution disagree on emailVisibility.

## Protections confirmed

Token policy keys are encrypted and purpose/domain bound; token rotation invalidates prior keyed sessions. Email action and OTP credentials are hashed, purpose-bound, expiry-bound, single-use, and use row locking around consumption. MFA challenges and TOTP counters are serialized, and MFA completion rechecks auth policy/rules before session issuance. OAuth state uses PKCE, encrypted verifiers, expiry, callback claiming, and configured provider endpoints apply HTTPS/loopback validation and response-size limits. Impersonation sessions are bound to active administrator sessions and targets.

## Verification

This is a static audit. No external OAuth, SMTP, or authentication operation was run. Existing integration tests in the batch document substantial concurrency and replay protections, but were not executed in this pass.

## Improvement sequence

1. Unify OAuth redirect validation (IUA-01) and add focused unit tests.
2. Decide and encode administrator email-verification semantics (IUA-02).
3. Align auth-rule validation with resolver support (IUA-03).

No source or test files were modified.
