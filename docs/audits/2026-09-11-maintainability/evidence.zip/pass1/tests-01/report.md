# Pass 1 — tests-01

Read all 31 fixed-snapshot test/support blobs (7,570 lines) in bounded chunks. No product edits were made.

The suite protects concrete operational contracts: compose stop-grace margins and draining; candidate digest pinning; CRUD/restart and relation behavior; release promotion/attestation/privacy/tag workflow rules; backup restore drills; PromQL dashboard-label compatibility; and context-bounded polling. Preserve integration tests that execute actual candidate images and release artifacts, since they cover contracts unit tests cannot.

No confirmed test defect was recorded. Keep skip baselines narrowly scoped by package/test and retain the polling guard. When release tests change, add assertions for failure diagnostics and cleanup as well as happy-path artifact promotion.
