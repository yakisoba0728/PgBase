# Pass 1 — internal-config-01

All assigned files were read in full from the fixed snapshot in no-more-than-200-line ranges.

Targeted verification: `go test ./internal/backup ./internal/config ./internal/cursor ./internal/cli ./internal/buildinfo` passed.

One evidence-backed configuration validation finding is recorded in `findings.json`. The backup, cursor, and CLI areas retain explicit ownership, signing, and cancellation boundaries; no additional confirmed defects were found in this pass.
