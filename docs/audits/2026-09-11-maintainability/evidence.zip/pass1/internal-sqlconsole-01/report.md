# Pass 1 — internal-sqlconsole-01

Read the 18 assigned fixed-snapshot blobs (5,661 lines) in bounded chunks. No product changes were made.

The module has strong defense in depth: analyzer rejects data-modifying CTEs and unqualified/system write targets; pool startup verifies separate role privilege envelopes; read guards inspect views and rewrite dependencies; runner uses bounded request/rollback/cancel contexts and discards unsafe connections; service scopes executions to actors and coordinates cancellation/persistence. Preserve these deep internal modules and their small `Runner`/`Service` interfaces.

No additional confirmed defect was recorded. Avoid collapsing analyzer, pool validation, and runtime revalidation: their overlap is intentional because catalog state can change after startup. If future changes touch cleanup, add regression tests for cancellation watcher exit, rollback deadline, and connection discard after failed cancellation.
