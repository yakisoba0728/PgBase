# Pass 1 — .github-01

Fixed baseline: `5cb721ff5590bf89b45ea9087d2ace0b74fe7127`.

All 10 assigned files were independently read in full from the fixed worktree, in <=100-line chunks where applicable. The prior generic root-CI artifacts were preserved under `rejected-pass1/.github-01-rootci/` and were not used as evidence.

## Findings

No confirmed defect was established in this batch. Review covered concrete workflow jobs, YAML/JSON keys, security boundaries, deployment defaults, test inputs/assertions, and audit publisher behavior. Historical audit claims were treated as documentation history, not current product defects.

## Preservation and plan

Preserve digest pinning, candidate/source binding, least-privilege permissions, secret generation boundaries, Compose hardening, and explicit policy assertions. Future maintenance can reduce repetition only if those checks remain independently visible at their trust boundaries.

## Verification

Static fixed-head source review only; no product source or tests were changed or executed.
