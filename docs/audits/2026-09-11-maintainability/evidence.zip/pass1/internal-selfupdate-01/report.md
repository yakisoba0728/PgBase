# Pass 1: internal-selfupdate-01

Read all 18 assigned files in full at their frozen blobs. One high-static-confidence integrity candidate is recorded as `PASS1-SELFUPDATE-01`; it needs the focused mutation test described in the finding to establish an executable reproduction.

The updater otherwise has strong defenses: exact signed-manifest parsing, same-origin downloads, bounded copies and digest checks, inode locking, private regular-file state, durable journal transitions, rollback verification, and crash-phase tests. Preserve the state-transition and locking comments because they document data-loss and concurrency invariants. No cleanup or LOC reduction is proposed.
