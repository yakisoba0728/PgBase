# Pass 1 — internal-repositorypolicy-01

All 8 assigned policy test files were read in numbered full-file chunks at snapshot 5cb721ff5590bf89b45ea9087d2ace0b74fe7127. Static review found no confirmed defect; no workflows or release scripts were executed.

## Preserved design

Preserve immutable digest promotion, candidate-first gates, full-history phase artifact selection, trusted-runner constraints, source-versus-harness checkout separation, backup-schema completeness, and explicit test preflight. These controls prevent release mutation, trust-boundary expansion, and silently skipped coverage.

## Refactor plan

1. Centralize repeated workflow section extraction in local test helpers (estimated +25/-55 LOC, medium confidence) without weakening literal security markers.
2. Move historical LOC accounting prose to a dated decision record only if each retained zero-slack value and rationale is linked from the test (estimated -90 LOC, low confidence); retain every comment explaining security, concurrency, data-loss, or no-headroom decisions.
3. Share fake-registry setup primitives between future promotion tests only where exact command logging remains observable (estimated +10/-25 LOC, low confidence).

Static evidence and unexecuted tests are separate: no CI workflow, image build, registry, or restore drill was run in this pass.
