# Pass 1 — internal-database-01

All assigned files were read from fixed snapshot 5cb721ff5590bf89b45ea9087d2ace0b74fe7127 in ranges of at most 200 lines.

Verification run: `go test ./internal/database ./internal/doctor ./internal/fieldvalue` — passed.

The database batch records one dynamic-reproduction candidate; it is not a confirmed defect. Doctor preserves a strong deep-module boundary by compiling expectations through the schema planner and inspecting one snapshot. Fieldvalue preserves bounded decoding and cryptographic generation.
