# PASS1 internal-api-02

Reviewer: `sub-sol-double-ui-first`  
Pinned source: `5cb721ff5590bf89b45ea9087d2ace0b74fe7127`  
Coverage: 34 files, 9924 lines, full source/model read.

The API keeps route admission, response buffering and deadlines explicit; owner-scoped operation recovery, strict JSON, redacted errors, canonical cursors and exact-number SQL parameters are especially strong.

## Findings

- **API2-P1-001 (P2):** Split schema transport DTOs from endpoint control flow — Move pure DTOs/converters and PocketBase catalog query/paging into two package-private files; share no new interface and preserve exact golden wire.
- **API2-P1-002 (P2):** Add cancellation propagation tests to long-running API adapters — Add a reusable blocking context-aware fake and table-driven tests for representative read, mutation and SQL paths. Keep detached cases as explicit separate tests.

## Verification boundary

Read-only static review; no product/test edits and no dynamic test execution. Acceptance tests above are proposed, not claimed.
