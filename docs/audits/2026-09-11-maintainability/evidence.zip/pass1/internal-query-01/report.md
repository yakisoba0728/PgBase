# Pass 1 — internal-query-01

Base: `5cb721ff5590bf89b45ea9087d2ace0b74fe7127`  
Reviewer: `sub-terra-double-records`  
Scope: 55 fixed files / 11,990 text lines.

## Coverage

All assigned Git blobs were read in full, with long files reviewed in bounded chunks. `coverage.json` records the blob, full inclusive range, and file-specific source responsibility or test assertion. No source or test was edited.

## Results

No independently supported actionable defect, security issue, or unsafe comment removal was recorded. The package has deliberately strong seams: the compiler owns catalog-derived SQL and keyset ordering; the codec owns physical/value conversion; cursor V5 signing binds continuation to typed order, query fingerprint, membership, and expiry; expansion planning/materialization has bounded work; and the page assembler measures the emitted representation before minting its cursor.

The integration tests are especially valuable safety evidence. They cover cursor cross-scope refusal and retirement, PostgreSQL time expiry, read snapshot identity, policy-before-order expansion, nested reverse expansion budgets, no-N+1 plans, response-byte trimming, and field visibility. Do not merge these layers merely to reduce file count: they are real seams with distinct variability and test contracts.

## Maintenance plan

No line-reduction change is recommended without a concrete maintenance trigger. `expand.go`, `expand_plan.go`, `expand_material.go`, and `expand_measure.go` already separate orchestration, plan validation, materialization, and sizing. The similarly focused cursor V5 files keep protocol compatibility inspectable. A future measured refactor could introduce a read-attempt context only if profiling shows parameter plumbing obscures a real defect; preserve the public query API, signed cursor bytes, exact wire budgeting, authorization filtering, and every existing cursor/expand integration case. Estimated impact: +15–30 / -30–50 LOC, low confidence, behavior-neutral.

## Verification

Static fixed-snapshot review only. The PostgreSQL-backed integration suite was not run in this audit pass; runtime reproduction is not claimed.
