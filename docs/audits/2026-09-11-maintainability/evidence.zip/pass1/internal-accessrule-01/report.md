# PASS1 internal-accessrule-01

Reviewer: `sub-sol-double-ui-first`  
Pinned source: `5cb721ff5590bf89b45ea9087d2ace0b74fe7127`  
Coverage: 7 files, 1632 lines, full source/model read.

All 7 files were read in full. The compilers bound values, quote catalog identifiers and enforce node/depth/path limits; PocketBase relation traversal is expressed as bounded EXISTS subqueries. One fail-open inconsistency treats invalid subject kinds as authenticated. A narrow shared typed-operand layer can reduce duplicated validation while keeping the two AST and relation semantics explicit.

## Findings

- **AR1-P1-001 (P1, security):** Reject invalid principals before evaluating PocketBase authenticated — Validate Principal.Valid at CompilePocketBase entry and use an explicit authenticated-kind switch; add invalid-kind tests.
- **AR1-P1-002 (P2, refactor):** Share typed operand and modifier validation between rule compilers — Extract only shared validated value/modifier/request primitives behind concrete functions; avoid a broad compiler interface and keep SQL relation logic separate.

## Verification boundary

This was a read-only source review. No product or test file was edited and no dynamic test was run. Proposed acceptance tests are plans, not claimed results.
