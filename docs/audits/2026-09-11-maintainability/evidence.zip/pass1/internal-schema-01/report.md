# Pass 1 — internal-schema-01

- Base: `5cb721ff5590bf89b45ea9087d2ace0b74fe7127`
- Reviewer: `sub_terra_audit_data`
- Scope: all 65 assigned production and test files were fully read; blobs and full ranges are recorded in `coverage.json`.
- Verification: static review only; no test command was run.

## Findings

1. **P2 — auth token-policy documents do not converge on removal.** `applyDocumentAuthCollections` upserts only supplied TTL purposes. The export path includes all rows, so an extra target policy remains after importing an otherwise authoritative document. The existing auth-document test validates an empty-target round trip and a present `session` policy; it does not exercise removal from a populated target. Confirm intended full-replacement semantics before deleting omitted rows.
2. **P3 — policy strings are not validated at import.** The document validator enforces numeric ranges and JSON rule shape but does not compile executable rule sources or password patterns. The current test rejects an invalid numeric policy but does not cover malformed policy strings. Reuse the runtime compilers at the import seam, with legacy-read compatibility considered.

## Good design to retain

The cache compiles an immutable snapshot and publishes only after commit; its prepared-snapshot discipline preserves transaction visibility. The operation ledger uses a caller-scoped HMAC cursor, canonical request hashes, leases/fencing, and reconciliation rather than returning raw database failures. Companion-index rollout separates activation proof, concurrent physical maintenance, and ready-state promotion under the schema lock. Default normalization explicitly distinguishes new input restrictions from legacy catalog readability.

## Improvement plan by area

- **Refactoring / LOC:** retain the existing deep modules. If adding auth-policy parsing, centralize it behind one validation interface used by preview and runtime rather than duplicating string checks.
- **Maintainability/comments:** preserve comments explaining cache publication, legacy default compatibility, cursor MAC canonicality, lease/DDL behavior, and companion-index cleanup; they record non-obvious invariants. No broad comment deletion proposed.
- **Stability:** retain bounded cleanup and ambiguous-commit reconciliation. Add a convergence test for an import onto a nonempty target, including missing auth token purposes.
- **Features/bugs:** decide and codify schema-document replacement versus patch behavior for auth token policies, then make export/import behavior match it.
- **Security:** keep owner-scoped operation history, cursor signing, encrypted newly imported token keys, and SQL identifiers sanitized. Validate executable auth policy strings before they reach their runtime sink.

## Verification status

No tests were executed. Findings are static candidates, not dynamically reproduced defects.
