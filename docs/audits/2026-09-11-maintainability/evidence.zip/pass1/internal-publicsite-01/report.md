# Pass 1 — internal-publicsite-01

All assigned files were read from fixed snapshot 5cb721ff5590bf89b45ea9087d2ace0b74fe7127 in no-more-than-200-line ranges.

Verification: `go test ./internal/membership ./internal/migrate ./internal/observability ./internal/passwordfield ./internal/publicsite` passed.

No confirmed defects were recorded. Preserve comments that explain membership lock ordering, migration compatibility, sensitive-data redaction, and static-file containment; they document security and state-transition invariants.
