# Pass 1: internal-usermigrate-01

Read all 10 assigned files at their frozen blobs. `PASS1-USERMIGRATE-01` is a high-static-confidence recovery candidate: a durable source row marked `written` is never rechecked, while recovery processes only `pending` rows. The prescribed deletion/recovery integration test is needed for a dynamic reproduction.

The core design is strong: generated migrations embed canonical snapshots, apply under both user-migration and schema-writer locks, protect the system control ledger from callbacks, record source bytes transactionally with the schema commit, and use hard-link publication to avoid overwrite races. Keep the comments explaining history cleanup and generated data-loss warnings; they document user-facing destructive boundaries.

Plan: centralize `verify-or-materialize` for both written and pending source records, restoring an absent exact artifact while retaining the existing conflict state for different bytes. This is approximately +35/-10 LOC; it preserves migration IDs, source bytes, checksum history, and no-overwrite behavior.
