# Pass 1 — internal-relation-01

All 18 assigned text files were read in numbered full-file chunks at snapshot 5cb721ff5590bf89b45ea9087d2ace0b74fe7127. Static review found no confirmed defect; no dynamic reproduction was run.

## Preserved design

Keep catalog-bound identifiers, opaque target-miss errors, UUID-sorted advisory and row locks, Read Committed enforcement, bounded graph traversal, deferred-cycle handling, transaction-bound relation cleanup, and ordered/budgeted hydration. These are authorization, data-preservation, anti-oracle, and deadlock controls rather than incidental implementation detail.

## Refactor plan

1. Split delete planning into metadata binding, closure discovery, and execution-plan assembly (estimated +20/-55 LOC, medium confidence), retaining the current lock acquisition and failure order exactly.
2. Extract the shared relation row scanner used by normal and replay hydration (estimated +15/-30 LOC, medium confidence), while keeping each SQL projection explicit because its field-selection contract differs.
3. Consolidate duplicated live fixture helpers only after retaining the separate-connection and opposite-order tests (estimated -35 LOC, low confidence).
4. Remove no current comments: lock, isolation, budget, anti-oracle, deferred-FK, and position-compaction explanations are necessary rationale.

Static evidence and unexecuted tests are separate: this pass ran no PostgreSQL integration test or race reproduction.
