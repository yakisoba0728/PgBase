# Pass 1 — internal-runtimesettings-01

All 3 assigned files were read in numbered full-file chunks at snapshot 5cb721ff5590bf89b45ea9087d2ace0b74fe7127. Static review found no confirmed defect; no database integration test was run.

## Preserved design

Keep AES-GCM domain separation, ciphertext-aware CAS, revision authority from the database, stale-reload non-regression, locally serialized listener publication, defensive slice copies, validation ceilings, and key-rotation locking. Together they preserve confidentiality, multi-process conflict detection, and in-process ordering.

## Refactor plan

1. Factor validation into small policy-specific validators while retaining the same inclusive bounds and one ErrInvalid surface (estimated +20/-35 LOC, medium confidence).
2. Encapsulate encrypted-row read/migration in a helper to shorten Reload (estimated +15/-30 LOC, medium confidence); preserve its compare-and-convert and reread sequence.
3. Keep all comments explaining ciphertext CAS, stale revisions, publication order, and rotation rollout; none are boilerplate.

Static evidence and unexecuted tests are separate: no migration, database integration, key rotation, or race test was run in this pass.
