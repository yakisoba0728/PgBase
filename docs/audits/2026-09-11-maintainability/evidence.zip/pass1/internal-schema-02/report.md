# Pass 1 — internal-schema-02

Static, read-only audit of all 36 assigned files at `5cb721ff5590bf89b45ea9087d2ace0b74fe7127`. No tests were run.

## Finding

`P1-internal-schema-02-001` is a static candidate: `schemaPolicyChecksum` captures collection access/rules and auth collection/policy timestamps/rules, while `ApplySchemaImport` later mutates auth token TTL policy rows through `applyDocumentAuthCollections`. The apply transaction locks the regular collection access/rules rows but not the auth realm policy/TTL state. A concurrent TTL edit can therefore evade the preview-policy checksum and be overwritten by a stale import. Add the TTL state (or a maintained realm revision) to the checksum, lock that state before re-planning, and test concurrent preview/apply behavior.

## Preserved contracts and observations

- `physical_manifest.go` and `physical_manifest_builder.go` make the expected physical schema an immutable deep module: required objects are separately cloned, user extras remain unowned, and relation namespace ownership is exact.
- `physical_manifest_test.go` pins deterministic ordering, clone isolation, ownership boundaries, core object counts, and companion-index eligibility; its integration counterpart compares catalog manifest entries to PostgreSQL catalog properties including index flags, constraints, triggers, and function bodies.
- `planner.go` preserves field IDs/physical columns through logical renames, rejects unsafe required scalar additions, and validates incoming relation/view deletion dependencies. `planner_test.go` asserts deterministic checksums/DDL, injection-shaped default rejection, widening only, and legacy-default carry-forward.
- `planner_indexes.go` has a narrow AST whitelist for keys/predicates/raw SQL and canonicalizes accepted index SQL. It rejects schema-qualified functions, unsupported operators, and unsafe parser modifiers.
- `relation_types.go` normalizes defaults, produces sorted validation details, distinguishes symbolic create-time self targets, and copies caller-owned state. `relation_types_test.go` exercises invalid bound/action/storage combinations and alias isolation.
- `relation_ddl.go` uses sanitized identifiers and deferred foreign-key/constraint triggers for relation edges. `relation_planner_integration_test.go` commits valid edge edits and verifies deferred cycle-delete behavior.
- `relation_service_integration_test.go` protects stale-plan rollback, metadata failure rollback, required-relation backfill checks under the apply lock, and incoming-target deletion guards. `relation_store_test.go` verifies deterministic incoming ordering and hides corrupt catalog values in integrity errors.
- `preflight.go` compiles/publishes only after the repeatable-read transaction commits; `preflight_integration_test.go` covers pre-migration catalogs, budget rejection, listener reuse, and cancellation cleanup.
- `schema_document.go` does preview DDL in a savepoint, orders dependent views, re-plans and checks the import checksum under the schema lock, and publishes cache only after commit. Document tests cover merge preservation, projected rule validation, export/apply round trips, idempotency receipt ownership, live-vs-orphan operation status, and late failure rollback.
- `schema_writer_runtime_integration_test.go` covers listener lease refresh, migration compatibility, generation fencing, activation refusal for mixed fleets, and deadlock avoidance while long schema DDL is held.

## Maintenance plan

Keep the current deep-module boundaries: planner produces deterministic plans; manifest owns only project objects; store validates persisted graph integrity; import applies atomically. The actionable change is isolated to the auth-policy conflict seam described in finding 001. Avoid broad refactors or comment churn.
