# pgbase-02 pass 1 replacement review

Base `5cb721ff5590bf89b45ea9087d2ace0b74fe7127`; reviewer `sub-sol-first-pgbase-replacement`. I read all 80 assigned files (11285 lines) from the fixed worktree as raw text in chunks no larger than 150 lines. Coverage records the complete per-file range and a file-specific responsibility, assertion, risk, or preservation note. Product source and tests were not modified.

## Findings

- **PGB02-001 P2 — Extension object streaming buffers the full object in memory**: Each concurrent download retains a complete object before writing the response. Proposed acceptance coverage: Serve a large object through the JS route and assert first bytes arrive before the backing reader reaches EOF.; Assert content type, CSP, disposition, cache headers, full body, and cancellation cleanup.
- **PGB02-002 P3 — JavaScript response paths duplicate status and body emission rules**: Equivalent response invariants are maintained across several branches and tests must catch drift. Proposed acceptance coverage: Table-test JSON/text/empty responses for GET and HEAD with gzip accepted, rejected, wildcard, and q=0.; Assert no duplicate status writes and exact Vary/nosniff behavior.

## Preserved defenses and contracts

The review preserves strict one-value JSON decoding, authority checks before request-log/auth/schema operations, record-rule projection, schema base-version/checksum/idempotency contracts, SQL row/column limits, request-scoped transaction rollback, file-handle quotas, rooted symlink-aware filesystem checks, response-header filtering, HTTP drain ordering, migration compatibility checks, and exact public response shapes. Test comments that explain security, concurrency, data preservation, or state transitions should remain.

## Improvement and line-reduction plan

First fix boundedness and shutdown/redirect correctness behind the existing public interfaces. Then consolidate only repeated response-writing and extension adapter plumbing whose callers share the same validation contract. Estimated changes for this batch are recorded per finding as gross added/deleted LOC; reductions come from removing duplicate branches, not compressing code, deleting tests, or weakening defenses. Repetitive comments that merely restate the following statement may be removed during implementation, while capability, transaction, shutdown, migration, security, and compatibility rationale comments stay.

## Verification status

This was an audit-only pass. Static control-flow and contract inspection was performed. Commands listed in findings are proposed focused checks and were not run because their regression tests do not yet exist; no external service was contacted. The prior rejected findings were consulted only after the independent read: its two boundedness findings are accepted with narrower compatibility and failure-semantics requirements; the replacement adds independently found lifecycle, ACME-host, streaming, and response-writer observations.
