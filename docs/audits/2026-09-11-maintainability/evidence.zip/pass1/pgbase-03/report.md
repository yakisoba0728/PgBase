# Pass 1 — pgbase-03

Fixed baseline: `5cb721ff5590bf89b45ea9087d2ace0b74fe7127`.

All 22 assigned files were read in full at their pinned blobs.

## Findings

- ROOTCI-P1-001 (P2): ACME hostname syntax is permissive in `pgbase/tls.go`; validate DNS labels during normalization.

## Preservation and plan

Keep existing release digest/attestation checks, CI pinning, secret-redaction, migration/checksum commentary, and deployment hardening. Any future refactor should consolidate only repeated policy checks while retaining the explicit security gates.

## Verification

Static fixed-head source review only; no product code or tests were changed or executed for this audit.
