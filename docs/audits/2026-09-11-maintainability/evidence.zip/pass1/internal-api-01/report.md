# Pass 1 — internal-api-01

Reviewed the 55 assigned `internal/api` files from fixed commit `5cb721ff5590bf89b45ea9087d2ace0b74fe7127` (11,737 declared text lines). Each blob was re-read in consecutive 200-line-or-smaller ranges; `coverage.json` records the complete `[1, lineCount]` range and a unique responsibility/assertion observation per file. No product source or test was changed.

## Verification

`go test ./internal/api` passed. This is a current-worktree execution check; the assigned files are unchanged from the fixed snapshot, and all audit source reads used `git show <base>:<path>`.

## Confirmed finding

- **API-RT-001 (P2 stability):** multipart batch cleanup deliberately detaches from request cancellation but also loses the request deadline. A stalled cleanup backend can therefore block the handler without bound. The focused change is a single private cleanup helper with an explicit timeout, preserving response and storage-completion contracts.

## Good design to preserve

- Declarative route metadata validates admission policy, response cap, request cap, and deadline policy before registration. This is a deep module with a small, useful route interface.
- Admin middleware combines trusted-proxy handling, same-origin checks, CSRF checks, strict session-token validation, and explicit unavailable/rate-limited error mapping without exposing credentials.
- JSON request handling rejects incorrect media types, malformed Unicode, duplicate keys, unknown fields, and trailing values.
- Realtime sessions serialize replacement with delivery and enforce global/per-user admission counts; record paths validate conditional and idempotency headers at the API boundary.

## Improvement plan

1. Address API-RT-001 with one bounded private cleanup seam; do not expose it through the route or file-service public interfaces.
2. Add regression tests at the API boundary using a blocking cleanup fake, including cancellation and timeout behavior.
3. Re-run `go test ./internal/api` and the relevant integration-tag suite where storage cleanup is exercised.

No additional confirmed functional, authorization, serialization, status, request-limit, or secret-exposure defect was identified in this pass. Several repetitive error/response paths are intentional because they preserve endpoint-specific API contracts; do not abstract them until a real behavioral variation is shared.
