# PASS1 internal-apiratelimit-01

Reviewer: `sub-sol-double-ui-first`  
Pinned source: `5cb721ff5590bf89b45ea9087d2ace0b74fe7127`  
Coverage: 3 files, 164 lines, full source/model read.

The limiter uses one atomic PostgreSQL statement for distributed admission and HMAC bucket identities, and runtime disabling is immediate.

## Findings

- **ARL-P1-001 (P1):** Deep-copy excluded IP settings before atomic publication — Clone ExcludedIPs alongside Rules, or add a canonical deep Clone method to runtimesettings.Settings and use it at all atomic snapshot boundaries.
- **ARL-P1-002 (P2):** Return the actual retry-query error when quota state cannot be read — Return qerr on the second failure and wrap it with bounded operation context; keep SQL/body details out of HTTP output.

## Verification boundary

Read-only static review; no product/test edits and no dynamic test execution. Acceptance tests above are proposed, not claimed.
