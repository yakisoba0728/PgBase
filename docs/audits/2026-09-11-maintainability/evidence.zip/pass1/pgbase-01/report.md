# pgbase-01 pass 1 replacement review

Base `5cb721ff5590bf89b45ea9087d2ace0b74fe7127`; reviewer `sub-sol-first-pgbase-replacement`. I read all 65 assigned files (11974 lines) from the fixed worktree as raw text in chunks no larger than 150 lines. Coverage records the complete per-file range and a file-specific responsibility, assertion, risk, or preservation note. Product source and tests were not modified.

## Findings

- **PGB01-001 P2 — app.record.findAll materializes an unbounded admitted collection**: Memory and final response size grow with the entire rule-filtered collection. Proposed acceptance coverage: Seed more than the cap, call findAll, and assert the stable limit code without returning a partial array.; Seed records hidden by rules and assert paging/capping never bypasses projection.
- **PGB01-002 P2 — objects.deletePrefix retains every matching key before deletion**: Memory grows with key count and no progress is made until the full listing succeeds. Proposed acceptance coverage: Create more than three pages, delete the prefix, and assert every match and hook outcome.; Inject a middle-page failure and assert documented partial-progress behavior.
- **PGB01-003 P2 — ACME HTTP redirect reflects an untrusted Host header**: The PgBase endpoint can emit a temporary redirect to an arbitrary HTTPS authority supplied by the client. Proposed acceptance coverage: Send Host evil.example to the challenge listener and assert 400 with no Location.; Send an allowed host with a path/query and assert the exact HTTPS redirect.
- **PGB01-004 P2 — The first Close caller permanently supplies the cleanup context**: A transient first caller deadline can determine final cleanup completeness and the error returned to all later Close calls. Proposed acceptance coverage: Call Close first with a canceled context, then with a live context, and assert pool/gate/background cleanup completes once.; Assert each caller still returns promptly at its own deadline.

## Preserved defenses and contracts

The review preserves strict one-value JSON decoding, authority checks before request-log/auth/schema operations, record-rule projection, schema base-version/checksum/idempotency contracts, SQL row/column limits, request-scoped transaction rollback, file-handle quotas, rooted symlink-aware filesystem checks, response-header filtering, HTTP drain ordering, migration compatibility checks, and exact public response shapes. Test comments that explain security, concurrency, data preservation, or state transitions should remain.

## Improvement and line-reduction plan

First fix boundedness and shutdown/redirect correctness behind the existing public interfaces. Then consolidate only repeated response-writing and extension adapter plumbing whose callers share the same validation contract. Estimated changes for this batch are recorded per finding as gross added/deleted LOC; reductions come from removing duplicate branches, not compressing code, deleting tests, or weakening defenses. Repetitive comments that merely restate the following statement may be removed during implementation, while capability, transaction, shutdown, migration, security, and compatibility rationale comments stay.

## Verification status

This was an audit-only pass. Static control-flow and contract inspection was performed. Commands listed in findings are proposed focused checks and were not run because their regression tests do not yet exist; no external service was contacted. The prior rejected findings were consulted only after the independent read: its two boundedness findings are accepted with narrower compatibility and failure-semantics requirements; the replacement adds independently found lifecycle, ACME-host, streaming, and response-writer observations.
