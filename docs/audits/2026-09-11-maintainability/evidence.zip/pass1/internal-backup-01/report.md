# Pass 1 — internal-backup-01

All assigned files were read in full from the fixed snapshot in no-more-than-200-line ranges.

Targeted verification: `go test ./internal/backup ./internal/config ./internal/cursor ./internal/cli ./internal/buildinfo` passed.

No confirmed findings were recorded for this batch. Preserve the explicit ownership, signed cursor, and cancellation/cleanup boundaries observed here.
