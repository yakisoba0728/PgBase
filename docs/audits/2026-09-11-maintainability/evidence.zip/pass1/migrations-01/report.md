# Pass 1: migrations-01

Read all 68 assigned migration and migration-test files at their frozen blobs, including every SQL migration and embedded byte/checksum path. No definite defect or sufficiently grounded candidate was found in this batch.

The migration chain is append-only and is protected by the embed loader's ordered checksums. The SQL files evolve catalog, relation, record identity, auth, service-token, extension, settings, and SQL-console state through additive/data-preserving transitions; the test suite checks migration ordering/checksums, schema operations, relations, membership, companion indexes, and console policies against PostgreSQL.

Do not consolidate, reformat, or remove comments from historic SQL migrations: their exact bytes participate in the system migration checksum contract. Maintenance changes should be made as new numbered migrations with explicit backfill and rollback considerations. No LOC-reduction change is proposed.
