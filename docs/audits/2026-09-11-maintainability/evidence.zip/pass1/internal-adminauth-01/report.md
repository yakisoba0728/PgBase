# PASS1 internal-adminauth-01

Reviewer: `sub-sol-double-ui-first`  
Pinned source: `5cb721ff5590bf89b45ea9087d2ace0b74fe7127`  
Coverage: 25 files, 5023 lines, full source/model read.

All 25 files, including the golden login trace, were read in full. The package has strong credential architecture: strict Argon2 parameters, dummy work, no connection held during KDF, locked recheck before issue, HMAC-only OTP/reset storage, encrypted TOTP, atomic revocation and bounded advisory-locked cleanup. Harden reset URL configuration and consolidate repeated limiter transitions without obscuring database lock order.

## Findings

- **AA1-P1-001 (P2, security):** Restrict password-reset links to safe URL schemes — Validate scheme/host at ConfigurePasswordReset, normalize the base URL, reject userinfo/fragments, and add an explicit development exception rather than accepting arbitrary schemes.
- **AA1-P1-002 (P2, refactor):** Extract the repeated rate-limit transition protocol without hiding locks — Extract concrete check/fail/succeed helpers parameterized by purpose and subject; keep Store SQL and lock acquisition visible and document only the lock-order invariant.

## Verification boundary

This was a read-only source review. No product or test file was edited and no dynamic test was run. Proposed acceptance tests are plans, not claimed results.
