# Pass 1: internal-serviceauth-01

Read both assigned files in full at the frozen blobs. No definite defect or sufficiently grounded candidate was found.

`Issue` stores only a domain-separated HMAC; `Authenticate` uses database time and hides token lookup status; `Authorize` obtains `FOR SHARE` in the protected transaction, which makes revocation wait. The integration tests cover the critical revocation/authorization race and prevent a joined-row pagination regression in `List`.

Preserve the token-row lock and the `listed` CTE: they bind authorization to revocation and bound the number of tokens without truncating scopes. No comment cleanup or LOC-reduction change is proposed.
