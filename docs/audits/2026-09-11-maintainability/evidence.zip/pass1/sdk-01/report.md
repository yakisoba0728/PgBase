# SDK pass 1 — sdk-01

Reviewed the snapshot at `5cb721ff5590bf89b45ea9087d2ace0b74fe7127`, covering all 48 assigned Dart, JavaScript declaration, and TypeScript source, generated distribution, test, example, configuration, lock, and conformance files. Full textual reads used bounded line chunks; lockfiles were parsed as structured JSON/YAML and recorded as `structured_full_read`.

The primary static defect is **SDK-01-001**: Dart's multiplexed realtime client does not inspect the SSE handshake response before waiting for `PB_CONNECT`. Error handshakes therefore leave `subscribe()` pending and retry indefinitely. Record-event SSE already has the required status conversion, and TypeScript has terminal readiness tests, making the absence in Dart clear.

**SDK-01-002** is a maintainability reduction: the two Dart OAuth browser-flow copies have the same state/origin/cancellation cleanup decisions. A carefully parameterized private helper would delete roughly 80 lines while preserving public behavior. The global OAuth link/complete routes are intentional; server route inspection confirms realm-specific start with global link/complete.

Good design to preserve: exact JSON retains numeric spelling and rejects duplicate keys; auth-store generations prevent stale refresh/storage writes; record writes retain idempotency and strong ETag invariants; the separate admin client protects the cookie/CSRF boundary; TypeScript realtime correctly distinguishes terminal from retryable handshake failures. Preserve security/concurrency/API comments that explain these choices.

Validation attempted: `npm test` stopped at `tsc: command not found`; `dart test` stopped at `dart: command not found`. No live conformance command ran because it requires credentials and a server. Existing source and tests were inspected; test results here are static only.

No source or test files were edited.
