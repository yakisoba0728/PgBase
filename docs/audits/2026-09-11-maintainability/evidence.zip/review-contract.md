# 전체 코드베이스 2회 감사와 개선 계획

사용자 요청: 추적 파일을 하나하나 두 번 읽고, 기능 영역별 리팩토링·코드 감소·안정성·버그·기능 완성·보안·불필요한 주석 정리 계획을 만든다. 이번 단계에서는 제품 소스와 테스트를 수정하지 않는다. 격리 재현 코드는 .local에만 작성한다.

## 감사 원칙
- inventory.json의 고정 커밋/blob을 기준으로 한다. 과거 감사가 현재 결론을 대신하지 않는다. 20개 수정 결함을 이유 없이 재오픈하지 말고 현재 경로를 확인한다.
- 각 배정 파일의 텍스트 전체를 실제로 읽는다. rg나 함수 목록, 앞뒤 일부, 파일 크기만으로 읽기 완료를 선언하지 않는다. 출력이 잘리면 작은 범위로 다시 읽는다. 긴 한줄 생성물은 의미있는 구조로 전체 내용을 파싱해 읽고 structured_full_read로 구분한다. 바이너리는 binary_inspected로 분리하고 형식/생성원본/무결성 근거를 남긴다.
- 파일별 blobSha, pass, reviewer, readRanges, method, 구체적인 파일별 관찰을 기록한다. 자동 생성한 형식적 동일 문장이나 실제 읽지 않은 전체범위 기입은 금지한다. coverage는 선언과 누락을 검증할 뿐 독자의 이해를 기계적으로 증명하지 않는다.
- 2차는 해당 batch의 1차 작성자가 아닌 다른 reviewer가 전체를 다시 읽는다. 처음에는 1차 findings를 보지 않고 독립 검토하고, 그 다음 1차 findings를 비교하여 accept/reject/narrow/defer로 판정한다. 1차 보고서만 읽고 2차 완료로 간주하지 않는다.
- 결과는 확정 결함, 정적 근거가 강한 후보, 동적 재현 필요, 유지보수 개선, 의도된 차이를 구분한다. 보안은 공격자/권한/입력/sink/방어경로와 실제영향을 함께 설명한다. 비밀을 출력하거나 외부 서비스를 공격/변경하지 않는다.
- 중복 제거, dead code, pass-through abstraction, 한곳으로 모을 불변식, race/cancel/rollback/commit/cleanup, API/SDK/UI 계약, validation/authorization, dependencies/CI, 테스트 신뢰도를 본다.
- 줄 감소는 작은글씨·한줄압축·주석제거·기능삭제로 달성하지 않는다. 유지될 기능과 삭제/통합할 구체 경로를 명시하며 gross+/− 및 추정의 신뢰도를 기록한다.
- 주석은 구현을 그대로 반복/이미 무효/과거 작업일지이면 제거·문서이동 후보; 동시성·보안·데이터보존·상태전이 이유, 공개API 계약, 라이선스, 생성물표식은 보존한다.
- 공개 API/SDK 호환, DB migration/checksum, 데이터 보존, exact numbers/text IDs, 권한검사, 사용자 UX를 유지한다. 기능 변경은 기존 계약의 버그수정인지 새기능인지 구분한다.
- 코드 설계 스킬 원칙: 작은 Interface 뒤 깊은 Module, 실제 변동이 있는 Seam만, 호출자와 검증이 동일 Interface를 사용, 유효한 중복/명시성을 과도하게 추상화하지 않는다.

## 산출물 (각 pass/batch 디렉터리)
coverage.json: {baseSha,pass,reviewer,batchId,entries:[{path,blobSha,method,readRanges:[[start,end]],observation}]}
findings.json: {baseSha,pass,reviewer,batchId,findings:[{id,category,priority,title,paths:[{path,start,end}],trigger,evidence,currentBehavior,desiredBehavior,confidence,verification:{kind,command,result},proposal,dependencies,compatibilityRisk,estimatedAddedLOC,estimatedDeletedLOC,estimateConfidence,acceptanceTests,commentAction}]}
report.md: 읽은 범위, 핵심 발견, 보존할 좋은 설계, 영역별 개선계획, 실제 실행/미실행 검증 구분.
2차는 adjudication.json 추가: 1차 각 ID의 accept/reject/narrow/defer 및 이유, 2차 새 발견은 별도 ID.
각 파일 읽기당 observation은 최소 1개의 실제 책임·위험·정리근거를 고유하게 적는다. 결함이 없으면 없다고 기록한다.
