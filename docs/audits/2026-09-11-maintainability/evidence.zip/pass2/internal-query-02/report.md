# Pass 2 — internal-query-02

Base: `5cb721ff5590bf89b45ea9087d2ace0b74fe7127`  
Reviewer: `sub-terra-second-data`  
Scope: 22 fixed files / 5,349 text lines.

## Independent reading

Read every assigned source and test blob from the dedicated base worktree in bounded 150-line windows before consulting pass 1. `coverage.json` records the exact blob, complete inclusive ranges, and a file-specific responsibility or test input/result. The review covered relation-aware filter/sort, policy, hydration, root-page and public query-service paths. Product source and tests were not modified.

## Findings and adjudication

No independently supported defect, security issue, contract break, unnecessary-comment removal, or reliable LOC-reduction change was found. Pass-one report prose explicitly says no actionable finding, while its zero-byte `findings.json` is incomplete metadata rather than evidence of no defects. No parseable pass-one IDs exist to adjudicate; `adjudication.json` records that limitation.

## Design and maintenance plan

Preserve the current ownership boundaries. In this scope, transaction closure/rollback, authorization before projection, parameterized SQL, cursor V5 request/scope binding, response-size measurement, membership fencing, idempotency hashes, relation locks, and hook/outbox ordering carry externally observable safety contracts. The accompanying integration tests use concrete transaction, concurrency, cursor, policy, and byte-budget inputs; they are not disposable duplication.

A future refactor should be triggered only by measured maintenance cost: an internal attempt context could collect stable per-operation inputs in `service.go` / `root_page.go`, removing repetitive parameter plumbing while keeping the public service surface and wire formats unchanged. Estimated impact: add 15–30 lines and remove 30–60 lines, low confidence. Do not remove comments that explain rollback, lock, scope-binding, cursor, or authorization decisions; they record non-local invariants rather than repeat syntax.

## Verification

Executed: `go test ./internal/query ./internal/recordops` at the pinned audit worktree (passed). This audit did not run PostgreSQL build-tag integration suites or alter external data.
