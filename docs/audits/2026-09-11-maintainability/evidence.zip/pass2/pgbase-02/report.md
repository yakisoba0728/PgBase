# pgbase-02 pass 2 review

Fixed base `5cb721ff5590bf89b45ea9087d2ace0b74fe7127`. This pass independently rechecked extension callers, lifecycle, TLS redirect, object-serving, and JSVM limit paths before comparing pass-one findings.

## Adjudication

- **PGB02-001 — narrow**: Open limits each object (default 5 MiB; configured files are capped at 100 MiB), so it is not unbounded. io.ReadAll still defeats streaming and allocates one full object per request. Keep as P3 performance/maintenance unless a public-route concurrent repro establishes availability impact.
- **PGB02-002 — reject**: The gzip writer necessarily owns Content-Encoding, Vary, and explicit HEAD suppression while the plain helper owns shared body emission. The existing helper already centralizes plain response behavior; no concrete drift was demonstrated.

## New findings

- **PGB02-003 P3 — Gzip negotiation accepts valid zero qvalues**: A response can use an encoding the client explicitly disallowed.

## Preserved contracts and plan

Keep JavaScript/public API shapes, record-rule projection, lifecycle drain ordering, TLS host policy, object-response CSP/cache/disposition, and gzip/HEAD semantics. Address P2 allocation and shutdown defects before optional bounded deletion or object-serving refactors. Any findAll limit must be explicit because an all-record PocketBase-compatible caller otherwise observes a behavior change.

## Verification

The focused lifecycle and gzip tests passed. Dynamic regressions for aggregate findAll bounds, a canceled-first Close, ACME rejected Host, and q=0.00 remain to be added; no product source or tests were modified in this audit.
