# PASS2 examples-01 report

Independent second full read completed for every assigned file. Reviewer: `sub-sol-double-ui-first`  
Pinned source: `5cb721ff5590bf89b45ea9087d2ace0b74fe7127`  
Coverage: 19 files, 774 lines, full source/model read.

All 19 example files were read in full. The examples demonstrate protected custom routes, reversible migrations, occurrence-stable job idempotency, lifecycle hooks and a real browser record/file/SSE flow. The user-notes stream loop has one concrete controller-replacement race, and logout rejection needs visible handling. Preserve the examples’ deliberate simplicity and documented in-memory token limitation.

## Findings

- **EX1-P1-001 (P2, bug):** Bind each SSE loop to its own AbortController — Capture const controller, assign it globally only for cancellation, pass controller.signal, and inspect controller.signal in catch.
- **EX1-P1-002 (P3, stability):** Handle rejected logout requests in the browser example — Wrap logout in try/catch; show the SDK error and either retain the session for retry or deliberately clear local state in finally, documented in the sample.

## Verification boundary

This was a read-only source review. No product or test file was edited and no dynamic test was run. Proposed acceptance tests are plans, not claimed results.
