# internal-schema-01 2차 감사

고정 SHA `5cb721ff5590bf89b45ea9087d2ace0b74fe7127`에서 배정된 65개 파일, 11,939줄을 테스트와 구현을 함께 전부 재독한 뒤 1차 findings를 판정했다. coverage에는 파일별 실제 함수/테스트 책임과 전체 줄 범위 및 고정 blob을 기록했다. 제품과 테스트는 수정하지 않았다.

## 결과

- `P1-internal-schema-01-001` reject: Schema import is explicitly merge based: TestSchemaImportMergePreservesOmittedFieldsAndIndexes requires omitted members to survive, and TokenTTLs is optional/omitempty. The update-only loop matches that patch contract. Import/export convergence onto a target with unrelated preexisting members is therefore not an established requirement.
- `P1-internal-schema-01-002` accept: Independent review confirms validation checks only JSON string shape and bounds, then persists PasswordPattern and rule strings without invoking runtime compilers. Narrow implementation to shared cycle-free validators rather than duplicating grammar.
- 독립 발견 `IS1-P2-001`: Schema import accepts auth regex and rule sources that runtime cannot execute.

## 보존할 설계

catalog version, policy checksum, plan checksum, operation receipt를 나눈 승인 경계와 advisory lock/fence generation은 유지해야 한다. DDL 실패와 취소 뒤 rollback/reconciliation, companion-index 세대 전환, 물리 manifest의 exact ownership, relation의 deferrable constraint와 delete graph, cursor HMAC 및 idempotency hash 방어를 단순화하면 안 된다. 이 이유를 설명하는 긴 주석은 구현 반복이 아니라 롤백 binary와 동시 writer의 계약을 기록하므로 보존 대상이다.

## 실행 계획

1. `IS1-P2-001`를 독립 PR로 처리하고 finding의 acceptance tests를 먼저 추가한다.
2. schema import의 checksum/merge/idempotency 기존 회귀군과 `go test ./internal/schema`를 실행한다.
3. PostgreSQL 통합 환경에서 stale preview, rollback, physical manifest 또는 auth-document round trip 중 변경 영역에 해당하는 테스트를 실행한다.

## 검증

`go test ./internal/schema`는 통과했다. 외부 서비스와 데이터는 변경하지 않았고 integration build-tag suite는 실행하지 않았다. LOC 추정은 해당 finding의 좁은 변경만 대상으로 하며 shared validator 이동은 패키지 cycle 해소 방식에 따라 변동 폭이 크다.
