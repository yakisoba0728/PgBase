# internal-selfupdate-01 PASS2 audit

At `5cb721ff5590bf89b45ea9087d2ace0b74fe7127`, all 18 assigned files (3,013 lines) were read from the fixed worktree before PASS1 comparison. Product and test files were unchanged. Coverage records exact blobs, full ranges, and file-specific responsibilities.

## Findings and adjudication

- `PASS1-SELFUPDATE-01` → **accept**: Independent full-path trace confirms Apply trusts exported mutable Candidate fields without proving membership in ManifestRaw authenticated by SignatureRaw and TrustKey. The finding is a package-boundary integrity defect even though current CLI wiring does not mutate the value.
- `P2-SELFUPDATE-01`: Apply does not bind the mutable selected artifact back to the signed manifest

## Preserved design

The review preserves checksum-bearing migration history, transaction-scoped PostgreSQL settings, advisory-lock ordering, relation delete/deferrable-constraint sequencing, SQL-console read-only and privilege boundaries, self-update digest/probe/rollback state, and exact source publication. Comments that explain those concurrency, security, compatibility, or durability reasons remain useful.

## Maintainability and LOC plan

Consolidate only repeated validation or state-transition code behind the same authoritative interface. Do not compress SQL migrations, remove tested explicit branches, alter embedded migration bytes/checksums, or weaken platform-specific update paths. For reported findings, estimated gross changes are +28/-2 LOC (medium confidence). Other cleanup is deferred until behavior-preserving duplication is demonstrated with callers and tests.

## Verification and acceptance

Static checks included SQL privileges, relation locks, runtime `SET LOCAL` behavior, migration ordering/checksum immutability, schema API compatibility, and filesystem publication/recovery. Existing focused Go tests were run for the two reported packages; integration suites requiring PostgreSQL were not run. Finding records contain trigger-specific acceptance tests. For batches without findings, existing tests are the preservation contract; no speculative rewrite is proposed.
