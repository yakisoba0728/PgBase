# internal/userauth 2차 감사

고정 SHA `5cb721ff5590bf89b45ea9087d2ace0b74fe7127`의 배정된 57개 파일, 11,055줄을 테스트부터 제품 코드 순으로 독립적으로 다시 읽었다. 각 blob은 assignments의 고정값과 대조했다. 이후에만 1차 findings를 열어 세 건 모두 판정했다. 제품 소스와 테스트는 수정하지 않았다.

## 핵심 결과

- `IUA-03`은 수용한다. `emailVisibility`는 SQL resolver와 actor/request context에는 있으나 저장 전 rule validator의 system-field 목록에만 빠져 있다.
- `IUA-01`은 범위를 좁힌다. 일반 begin 경로는 `providerRedirectURI` 검증 때문에 막히지만, global provider의 split return/provider redirect 경로는 안전한 provider callback과 약한 return allowlist를 조합할 수 있고 Apple form-post callback이 저장된 return URI로 code/state를 다시 보낸다.
- `IUA-02`는 보류한다. 직접 record update가 trusted administrator primitive인지, manage-rule 사용자 경로에서 verified 보존을 허용하는지가 상위 route 계약에 달려 있다. 이 영역만 보고 보안 결함으로 확정하면 관리자 호환 계약을 바꿀 위험이 있다.
- 새 finding `IUA2-01`: generic OIDC 검증은 다중 `aud`에 client ID가 하나라도 있으면 승인하고 `azp`를 검사하지 않는다. 서명, issuer, expiry, nonce 방어는 유지하면서 authorized-party 규칙을 추가해야 한다.

## 보존할 설계

세션·action·MFA·OAuth 토큰은 HMAC domain을 분리하고 원문을 저장하지 않는다. OAuth state, OTP, MFA challenge는 authRule 거부 전에 소비하지 않아 정책 수정 후 재시도가 가능하다. 비밀번호 KDF는 DB row lock 밖에서 수행한 뒤 hash를 lock 아래 재검사하며, session refresh와 last-provider unlink도 경쟁 조건을 명시적으로 직렬화한다. OAuth HTTP 및 avatar 경로의 크기 제한, redirect 거부, SSRF DNS/IP 재검증, secret redaction도 제거하거나 단순화하면 안 된다. 동시성·보안 이유를 설명하는 주석은 현재 구현만 반복하지 않고 중요한 불변식을 기록하므로 보존 대상이다.

## 실행 순서

1. 작은 호환성 PR로 `emailVisibility`를 auth-rule validator에 추가하고 collection create/update 및 실제 SQL evaluation 통합 테스트를 넣는다. 약 +8/−0 LOC, 높은 신뢰도다.
2. OAuth redirect PR에서 global/split return URI에 공통 validator를 적용한다. HTTPS와 명시적 loopback HTTP만 허용하고 userinfo/fragment를 거부한다. Apple callback이 저장 target만 쓰는 방어는 유지한다. 약 +18/−7 LOC, 높은 신뢰도이며 기존 cleartext redirect 설정은 마이그레이션 안내가 필요하다.
3. OIDC PR에서 audience 파서를 `aud` 값과 개수를 반환하도록 좁게 확장하고 `azp`를 검증한다. signed fixture로 single audience와 matching/missing/mismatched authorized party를 고정한다. 약 +18/−2 LOC, 중간 추정 신뢰도다.
4. 별도 계약 PR 전에 관리자 route가 `UpdateAuthRecord`를 호출하는 권한 경계를 확인한다. 이메일 변경 시 verification을 보존할지 초기화할지 명시한 테스트를 먼저 추가한다. 이 확인 전에는 동작을 바꾸지 않는다.

## 검증

`go test ./internal/userauth`를 실행했고 통과했다. integration build-tag 테스트는 데이터베이스가 필요한 환경 변경을 만들지 않기 위해 실행하지 않았으며, 전체 내용을 읽어 트랜잭션 경계와 기존 회귀 범위를 확인했다. 외부 OAuth/OIDC/SMTP 호출은 수행하지 않았다.
