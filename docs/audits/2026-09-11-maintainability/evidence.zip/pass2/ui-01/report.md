# ui-01 pass 2 — independent UI audit

Pinned base `5cb721ff5590bf89b45ea9087d2ace0b74fe7127`. The assigned 65 files / 11981 inventory lines were independently inspected before adjudication. Generated/minified assets and the lockfile were inspected structurally in full; authored source and tests were examined as text. The pass-two coverage records concrete evidence rather than treating parser success as a source-level read; no source conclusion is attributed to minified line offsets.

## Findings

- **TUI1-001 Split the collection designer around pure draft and recovery boundaries** (P2): Move pure conversion/persistence code first; preserve operation identity, one-hour recovery, stale-plan and unsaved-draft semantics. Gross estimate +120/-180 LOC.
- **TUI1-002 Split HTTP endpoint codecs by port without splitting authentication policy** (P2): Extract request/decode primitives and grouped port factories; retain lossless JSON, CSRF and 401 generation behavior centrally. Gross estimate +110/-170 LOC.
- **TUI1-003 Format and name the auth administration subeditors** (P3): Extract forms without widening their state or altering redaction/timeouts. Gross estimate +80/-90 LOC.
- **TUI1-004 Verify embedded dist is reproducible from the locked source build** (P3): Add a clean-tree build/byte-diff CI check; never hand-edit the bundle. Gross estimate +12/-0 LOC.

## First-pass adjudication

- `UI1-001` — **reject**: handler.go line 200 contains one Referrer-Policy Set; lines 188-192 are extension cache handling, so the asserted duplicate is absent at the pinned blob.
- `UI1-002` — **accept**: Independent read confirms one collection-designer hook owns codecs, recovery and orchestration; extraction must preserve its explicit lifecycle invariants.
- `UI1-003` — **accept**: Independent read confirms a single broad authenticated adapter; retain the deep shared request/auth boundary while grouping codecs.
- `UI1-004` — **accept**: Independent read confirms several distinct forms and mutation guards are compressed into the panel.
- `UI1-005` — **narrow**: The generated bundle is structurally inspectable; the actionable issue is missing reproducibility verification, not an inability to inspect all content.

## Verification boundary

Static pinned-source inspection, full JSON/lockfile parsing and generated-artifact structural inspection only. Proposed regression tests are specific acceptance work; no browser/backend suite was run in this audit.

## Per-file observations

- `ui/admin/dist/assets/index-Bd6EhZVZ.js` — uses 2 lifecycle effect(s); creates 36 AbortController(s); calls v1, catalog, onExpired, resume.
- `ui/admin/dist/assets/index-IVG7M31z.css` — Structured inspection of the complete minified generated artifact: it is the embedded production bundle/style output, so source-level conclusions are tied to src rather than minified line offsets.
- `ui/admin/dist/index.html` — Production HTML mounts #root and imports /admin/assets/index-Bd6EhZVZ.js plus index-IVG7M31z.css; these names must agree with embedded dist files.
- `ui/admin/e2e/authenticated/api-rate-limits.spec.ts` — Creates a guest-only /health/live rule, reloads settings, then proves a fresh guest context receives 200 followed by 429 while the authenticated System route remains usable.
- `ui/admin/e2e/authenticated/collections.spec.ts` — Creates two collections, edits the first, jumps directly to the second editor, then back/forward asserts field and delete-confirmation state never leaks between route identities.
- `ui/admin/e2e/authenticated/fixtures.ts` — Creates worker-scoped authenticated storage, removes it afterward, retries schema plans after catalog races, and generates worker/retry/randomized names so concurrent cleanup cannot collide.
- `ui/admin/e2e/authenticated/managed-restore.spec.ts` — Under the managed-backup fixture flag, waits for POST /api/admin/backups, asserts create and restore terminal ledger messages, and accepts the destructive restore dialog.
- `ui/admin/e2e/authenticated/phase2.spec.ts` — Exercises SQL views as read-only, managed-backup create/download/upload/delete, and atomic required-file create/replace; it checks batch response status and old attachment disappearance.
- `ui/admin/e2e/authenticated/phase3.spec.ts` — Persists presentation/help/hidden fields, transfers schema with a >safe-integer JSON default, and verifies imported records/schemas survive the workflow.
- `ui/admin/e2e/authenticated/phase4.spec.ts` — Drives later administrator completion scenarios against the real backend and asserts rendered state after the corresponding route/action transitions.
- `ui/admin/e2e/authenticated/product-completion.spec.ts` — Runs product-completion browser flows and asserts user-visible completion states rather than relying only on request success.
- `ui/admin/e2e/authenticated/records.spec.ts` — Creates and navigates records through the real UI, checking list/editor values and persistence at route boundaries.
- `ui/admin/e2e/authenticated/runtime-profile.spec.ts` — Checks runtime profile behavior through its administrator route and asserts the resulting displayed state.
- `ui/admin/e2e/authenticated/schema-operations.spec.ts` — Asserts typed /admin/schema-operations links, bounded owner ledger rows, redaction of SQL/request hashes, and operation status persistence across reload and fresh sign-in.
- `ui/admin/e2e/authenticated/session.spec.ts` — Starts with empty storage, signs in, signs out to /admin/login, reloads anonymous state, rejects a wrong password, then signs in again.
- `ui/admin/e2e/authenticated/stale-record.spec.ts` — Uses two tabs to force an ETag conflict; asserts the second draft stays visible/disabled, reload preserves the draft, and a later save succeeds.
- `ui/admin/e2e/authenticated/system.spec.ts` — Polls both system endpoints until dated samples exist, asserts operational and health readings, then ensures rendered body has no connection URL, password, secret, or configured admin password.
- `ui/admin/e2e/local/local-features.spec.ts` — Verifies compound-index filtered views, auth-realm/file upload-download-delete, local SDK registration/note/file flows, and one-time service-token reveal/revoke persistence.
- `ui/admin/e2e/onboarding/onboarding.spec.ts` — Serially creates the first administrator with the setup token and asserts the authenticated shell and email persist after reload.
- `ui/admin/embed.go` — Embeds all dist files into the Go binary, making build-artifact provenance and hash-named asset serving release-critical.
- `ui/admin/handler.go` — Serves the embedded SPA, rejects unsafe paths/methods, applies CSP/nosniff/no-referrer, and gives only hashed assets immutable caching; exactly one Referrer-Policy assignment exists.
- `ui/admin/handler_test.go` — Read all 174 lines; this file participates in the administrator UI's typed rendering, route, backend, test, or build contract.
- `ui/admin/index.html` — Vite source HTML mounts #root and starts /src/main.tsx; its un-hashed entry is rewritten by the production build.
- `ui/admin/package-lock.json` — Parsed lockfile JSON (lockfileVersion 3, 218 package records); it fixes the build dependency graph.
- `ui/admin/package.json` — Pins Node >=24 <25 and scripts for typecheck, Vitest, Playwright, and Vite build; React/Tiptap/lossless-json versions are exact rather than ranges.
- `ui/admin/playwright.config.ts` — Read all 46 lines; this file participates in the administrator UI's typed rendering, route, backend, test, or build contract.
- `ui/admin/src/app.test.tsx` — Tests shows the SQL console only for an enabled authenticated session; contains 57 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/app.tsx` — Selects setup/login/authenticated shell from SessionProvider state, canonicalizes the URL per screen, and constructs the SQL port once with the HTTP backend runtime.
- `ui/admin/src/assets/world-land-NOTICE.md` — Contains legal/source attribution required for the vendored visual asset; retain it as provenance documentation.
- `ui/admin/src/assets/world-land-paths.json` — Parsed the generated map JSON (127 path records); it is geometry data governed by the adjacent attribution notice.
- `ui/admin/src/auth/session.test.tsx` — Tests clears the authenticated shell when the server session expires; contains 9 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/auth/session.tsx` — Exports sessionFailure, SessionProvider, useSession; uses 3 lifecycle effect(s); creates 1 AbortController(s); calls onExpired, resume, setup, login.
- `ui/admin/src/backend/auth-input.ts` — Exports providerInput, templateInput, smtpInput.
- `ui/admin/src/backend/backup-storage-port.ts` — Exports BackupStorageSettings, BackupStorageUpdate, BackupStoragePort.
- `ui/admin/src/backend/conformance.test.ts` — Tests resumes an authenticated administrator; contains 60 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/backend/http-backend.test.ts` — Tests shares the authenticated cookie and CSRF boundary with SQL console requests; contains 100 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/backend/http-backend.ts` — Exports httpBackend; calls csrfToken, administrator, expiresAt, sqlConsoleEnabled.
- `ui/admin/src/backend/json.ts` — Exports parseJSON, stringifyJSON.
- `ui/admin/src/backend/ports.test.ts` — Tests never resolves an inherited property as a collection; contains 22 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/backend/ports.ts` — Exports AuthenticatedSession, SetupInput, SetupBackup.
- `ui/admin/src/backend/sql-console-backend.test.ts` — Tests sends the one execution identity and optional write idempotency key without changing tagged exact cells; contains 8 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/backend/sql-console-backend.ts` — Exports sqlConsoleModes, SQLConsoleMode, sqlConsoleStatuses.
- `ui/admin/src/backend/storage-port.ts` — Exports FileStorageSettings, FileStorageUpdate, FileStorageMigrationInput.
- `ui/admin/src/components/auth-administration-panel.tsx` — Exports AuthAdministrationPanel; uses 2 lifecycle effect(s); creates 4 AbortController(s).
- `ui/admin/src/designer/collection-designer.test.tsx` — Tests keeps a relation target the administrator chose when the collection name changes; contains 271 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/designer/collection-designer.ts` — Exports DraftField, RelationTargetOption, DraftEdit; uses 3 lifecycle effect(s); creates 1 AbortController(s); calls kind, administrator, exportDocument, catalog.
- `ui/admin/src/designer/collection-draft.test.ts` — Tests emits the exact server representation for every non-trivial default; contains 15 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/designer/field-options.test.ts` — Tests preserves precision, choice lines and zero bounds across editing; contains 6 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/designer/field-options.ts` — Exports DraftFieldOptions, draftFieldOptions, fieldOptionsInput.
- `ui/admin/src/extensions/admin-extensions.ts` — Exports AdminExtensionScreen, installAdminExtensionAPI, extensionScreen.
- `ui/admin/src/extensions/extension-screen.tsx` — Exports ExtensionScreen; uses 1 lifecycle effect(s).
- `ui/admin/src/main.tsx` — Mounts the App into #root under StrictMode, making session/routing effects run through React's development lifecycle checks.
- `ui/admin/src/oauth-provider-presets.test.ts` — Tests matches the PocketBase v0.40.3 provider registry; contains 2 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/oauth-provider-presets.ts` — Exports providerPresets.
- `ui/admin/src/operations/operation-history.test.ts` — Tests reads one bounded page without asking for a cursor first; contains 19 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/operations/operation-history.ts` — Exports OperationHistoryView, useOperationHistory; uses 1 lifecycle effect(s); creates 1 AbortController(s); calls operations.
- `ui/admin/src/operations/operation-recovery.test.ts` — Tests recovers a DDL that outlived the request and then committed as a success; contains 49 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/operations/operation-recovery.ts` — Exports operationFailureMessage, RecoveredStatus, OperationRecovery; uses 1 lifecycle effect(s); creates 1 AbortController(s); calls operation.
- `ui/admin/src/pages/advanced-field-inputs.test.tsx` — Tests strips only the local origin when portable editor links are enabled; contains 8 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/pages/auth-collections-page.test.tsx` — Tests creates a realm and saves its registration and scalar profile schema; contains 16 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/pages/auth-collections-page.tsx` — Exports AuthCollectionsPage; uses 1 lifecycle effect(s); creates 2 AbortController(s).
- `ui/admin/src/pages/backup-storage-page.test.tsx` — Tests saves only dirty settings with the current revision and tests only persisted settings; contains 23 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/pages/backup-storage-page.tsx` — Loads revisioned backup storage with AbortController cleanup; saves only dirty draft fields, keeps configured secrets blank, and disables test/save actions while a mutation is pending.
- `ui/admin/src/pages/collection-api-examples.test.tsx` — Tests typechecks generated user CRUD against the shipped SDK (required file: %s); contains 6 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/pages/collection-api-examples.tsx` — Exports collectionExample, CollectionAPIExamples; creates 1 AbortController(s); calls list, createWithETag, getWithETag.
