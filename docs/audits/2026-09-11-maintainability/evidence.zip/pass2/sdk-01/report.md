# SDK pass 2 — sdk-01

Reviewed snapshot `5cb721ff5590bf89b45ea9087d2ace0b74fe7127` independently before reading pass-1 findings. The batch includes all 48 assigned Dart SDK, examples, conformance harnesses, TypeScript source/distribution/tests, declarations, manifests, and locks.

Accepted pass-1 **SDK-01-001**: Dart's shared realtime handshake treats non-2xx responses as an SSE frame source. With no `PB_CONNECT`, `_ready` is never completed or failed, so the caller waits while the loop retries. This is a P1 reliability defect.

Accepted pass-1 **SDK-01-002** as a P2 maintenance improvement. The global and realm OAuth browser flows duplicate state, origin, error, and cleanup policy. Centralizing just that policy can reduce about 80 lines without changing routes.

New **SDK-01-003** is a P2 public-contract mismatch: TypeScript's mandatory `AuthMethods.oauth2` property is omitted by a supported legacy response used in its own test. Normalize it to an explicit disabled/empty object (preferred for parity with Dart), or make it optional consistently.

Keep the exact-JSON parser, auth generation fences, typed HTTP errors, upload digest/cancellation flow, record-event status gate, strong ETag/idempotency validation in Dart, and separate admin cookie/CSRF client. Keep comments that state persistence, replay, callback, and CSRF reasons; repeated OAuth prose can shrink only after extraction.

Verification run from the fixed worktree: TypeScript `tsc --noEmit` passed; `node --test sdk/typescript/test/admin.test.mjs sdk/typescript/test/realtime-terminal.test.mjs` passed (9 tests). Dart tests and live conformance were not run because the Dart SDK/server credentials are unavailable. No product or test files were edited.
