# PASS2 docs-06 report

Independent second full read completed for every assigned file. Read all ten pinned files in full at base `5cb721ff5590bf89b45ea9087d2ace0b74fe7127`: the three large JSON ledgers/inventory were consumed as lossless structured records, and the markdown, checkpoint, and Node reproduction script were directly read in their complete ranges. No product source or tests were changed.

The batch contains one high-confidence documentation/audit consistency defect. `tools-ledger.json` still marks 16 archive/cron/dbutils rows `indexed`; `tools-extra-ledger.json` marks the same rows `read`; `tools.md` calls the tools ledger authoritative but claims 185 read/0 indexed; and `coverage.py` hides the conflict by applying an implicit override. Make the effective ledger and override provenance explicit, or regenerate the raw ledger to match the report. This is maintenance/tooling work, not a product behavior defect.

The operations and tools comparison documents preserve useful intentional-difference boundaries: PostgreSQL leases, typed query plans, bounded mail, and durable realtime should not be called regressions merely because PocketBase exposes different APIs. `repro-ui.mjs` is a valuable narrow, offline reproduction fixture and should remain isolated from product tests. No secrets were output and no external calls were made. Verification was static only.
