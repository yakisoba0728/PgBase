# internal-database-01 pass 2 audit

Fixed snapshot `5cb721ff5590bf89b45ea9087d2ace0b74fe7127`: read all 13 assigned files (1,322 lines) independently before adjudication. Coverage records every fixed blob and full line range. Product source and tests were not modified.

## Static candidate requiring reproduction

`P2-DATABASE-ROLLBACK-EXPIRED-DEADLINE` (P2): Rollback cleanup receives an already-expired deadline after transaction timeout. BoundedCleanupContext strips cancellation then caps the new one-second deadline at parent.Deadline; an expired parent deadline therefore produces a context already expired before tx.Rollback starts.

## Plan and verification

Do not treat the database rollback item as confirmed until a pgx canceled-rollback test establishes whether the connection is recovered or closed; then implement the listed acceptance tests; preserve public CLI/API text, migration checksum and data behavior. No commands were executed against databases or external services during this audit.
