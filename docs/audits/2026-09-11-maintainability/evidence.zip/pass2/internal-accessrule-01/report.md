# Pass 2 — internal-accessrule-01

Reviewed all 7 assigned fixed blobs (1632 lines) at `5cb721ff5590bf89b45ea9087d2ace0b74fe7127` in raw chunks of at most 150 lines before opening pass-1 findings. Product and test files were not modified.

## Findings and verification class

- **ACCESSRULE-001 (caller-contract needs verification)** — PocketBase authenticated macro admits an invalid identity subject

## Preserved design

Preserve the route registry as the authority for access, deadlines, request limits, and response modes; keep authentication tokens out of logs and quota buckets; preserve parameterized access-rule SQL, transaction-scoped authentication state changes, exact wire fixtures, and bounded cryptographic admission.

## Improvement plan

Apply only the focused proposals in findings.json. Keep public API/SDK wire shapes, exact IDs, database state, authorization ordering, and existing response codes stable. Avoid a broad shared handler abstraction across endpoint families.

## Validation

Static findings are separated from caller-contract verification in findings.json. Package tests were executed locally; no external SMTP, OAuth provider, or service was contacted.
