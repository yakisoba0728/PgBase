# pgbase-01 pass 2 review

Fixed base `5cb721ff5590bf89b45ea9087d2ace0b74fe7127`. This pass independently rechecked extension callers, lifecycle, TLS redirect, object-serving, and JSVM limit paths before comparing pass-one findings.

## Adjudication

- **PGB01-001 — accept**: The result cap occurs after findAll has accumulated and marshaled all pages; it does not bound internal peak allocation. Preserve all-record compatibility through an explicit limit or versioned paging plan.
- **PGB01-002 — defer**: The keyset List query makes page-at-a-time deletion feasible, but current enumeration failure causes zero deletes whereas interleaving makes partial progress observable. This is a P3 design/maintenance decision, not a drop-in bug fix.
- **PGB01-003 — narrow**: A valid attacker-selected Host is reflected into the fallback redirect although autocert HostPolicy prevents certificate issuance. Treat as P3 open-redirect hardening unless proxy/cache impact is demonstrated; normalize host/port and check ACMEHosts.
- **PGB01-004 — accept**: The first caller supplies the context used by shared closeResources; existing tests cover separate first and concurrent deadlines but not canceled-first then live cleanup.

## New findings

- **PGB01-001 P2 — findAll allocates the complete result before the JSVM output limit**: Aggregate memory and work grow with all permitted records; eventual JSVM limit rejection is post-allocation.
- **PGB01-004 P2 — The first Close caller's canceled context can poison shared cleanup**: Later callers can only wait for a cleanup attempt already canceled by the first caller.

## Preserved contracts and plan

Keep JavaScript/public API shapes, record-rule projection, lifecycle drain ordering, TLS host policy, object-response CSP/cache/disposition, and gzip/HEAD semantics. Address P2 allocation and shutdown defects before optional bounded deletion or object-serving refactors. Any findAll limit must be explicit because an all-record PocketBase-compatible caller otherwise observes a behavior change.

## Verification

The focused lifecycle and gzip tests passed. Dynamic regressions for aggregate findAll bounds, a canceled-first Close, ACME rejected Host, and q=0.00 remain to be added; no product source or tests were modified in this audit.
