# ui-02 pass 2 — independent UI audit

Pinned base `5cb721ff5590bf89b45ea9087d2ace0b74fe7127`. The assigned 70 files / 8273 inventory lines were independently inspected before adjudication. The review specifically traced cancellation, late completion, blob URL lifetime, public URL origin/path validation, and concrete UI/request assertions. No product/test file was changed.

## Findings

- **TUI2-001 Suppress late setup-restore polling fulfillment** (P1): Capture an active/generation token and check it in fulfillment and rejection; optionally add AbortSignal to the port. Gross estimate +8/-1 LOC.
- **TUI2-002 Suppress stale managed-backup poll callbacks** (P1): Guard both callbacks with the signal or an issued-generation check. Gross estimate +5/-2 LOC.
- **TUI2-003 Reject non-success public-file responses before using their blobs** (P2): Share fetchPublicBlob that requires response.ok and preserve credentials: omit. Gross estimate +8/-2 LOC.
- **TUI2-004 Revoke the final attachment preview object URL on field unmount** (P2): Track the active preview URL in a ref and release it in cleanup without double-revoking user-close. Gross estimate +7/-0 LOC.
- **TUI2-005 Decompress revisioned settings UI before further changes** (P3): Format first, then extract coherent profile and rate-rule controls with no behavioral change. Gross estimate +55/-65 LOC.

## First-pass adjudication

- `UI2-001` — **accept**: The fulfilled callback has no aborted/generation check and its port does not accept a signal.
- `UI2-002` — **accept**: The polling then/catch callbacks differ from adjacent guarded callbacks and can mutate after cleanup.
- `UI2-003` — **accept**: safePublicURL constrains the URL but both fetch paths skip Response.ok.
- `UI2-004` — **accept**: The only FileField preview revocations are replace/close; final unmount cleanup is absent.
- `UI2-005` — **defer**: The concrete stale callbacks should be fixed first. A shared cancellation hook risks flattening different operation-recovery semantics and needs a focused design pass.
- `UI2-006` — **accept**: The settings page is behaviorally substantive but compressed; formatting/component boundaries are a low-risk maintenance improvement.

## Verification boundary

Static pinned-source inspection, full JSON/lockfile parsing and generated-artifact structural inspection only. Proposed regression tests are specific acceptance work; no browser/backend suite was run in this audit.

## Per-file observations

- `ui/admin/src/pages/collection-designer-page.test.tsx` — Tests previews a self relation built from the live catalog; contains 38 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/pages/collection-designer-page.tsx` — Exports CollectionDesignerPage.
- `ui/admin/src/pages/collection-field-editor.tsx` — Exports CollectionFieldEditor.
- `ui/admin/src/pages/collections-page.test.tsx` — Tests lists collections in name order with their field and relation counts; contains 11 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/pages/collections-page.tsx` — Exports CollectionsPage; uses 2 lifecycle effect(s); creates 3 AbortController(s); calls truncate.
- `ui/admin/src/pages/field-options-editor.test.tsx` — Tests edits and clears generation, allow, and deny values; contains 4 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/pages/field-options-editor.tsx` — Exports FieldOptionsEditor.
- `ui/admin/src/pages/file-field.test.tsx` — Tests uploads, deletes, and revokes a downloaded object URL; contains 11 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/pages/geo-point-field.tsx` — Exports GeoPointField; uses 1 lifecycle effect(s).
- `ui/admin/src/pages/login-page.test.tsx` — Tests shows validation errors and does not submit incomplete credentials; contains 20 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/pages/login-page.tsx` — Exports LoginPage; uses 1 lifecycle effect(s).
- `ui/admin/src/pages/operations-console.test.tsx` — Tests does not offer backup writes on a server without managed backups; contains 22 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/pages/operations-console.tsx` — Exports OperationsConsole; uses 4 lifecycle effect(s); creates 6 AbortController(s); calls backups, backupJob.
- `ui/admin/src/pages/record-edit-page.test.tsx` — Tests requires and atomically creates a record with its selected files; contains 35 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/pages/record-edit-page.tsx` — Exports FileField, RecordEditPage; uses 3 lifecycle effect(s); creates 1 AbortController(s); calls listFiles, uploadFile, downloadBlob, createDownloadToken.
- `ui/admin/src/pages/record-rules-editor.test.tsx` — Tests edits a preset and saves the typed rules revision; contains 3 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/pages/record-rules-editor.tsx` — Exports RecordRulesEditor; uses 1 lifecycle effect(s).
- `ui/admin/src/pages/records-page.test.tsx` — Tests renders a value outside the JavaScript safe integer range without rounding it; contains 15 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/pages/records-page.tsx` — Exports RecordsPage; uses 1 lifecycle effect(s); calls kind, administrator.
- `ui/admin/src/pages/rich-text-field.tsx` — Exports portableHTML, RichTextField; uses 3 lifecycle effect(s).
- `ui/admin/src/pages/schema-operations-page.test.tsx` — Tests renders one bounded page of redacted receipts; contains 16 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/pages/schema-operations-page.tsx` — Exports SchemaOperationsPage.
- `ui/admin/src/pages/schema-transfer-page.test.tsx` — Tests retains bounded recovery metadata for unknown results and retries the exact in-memory plan; contains 14 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/pages/schema-transfer-page.tsx` — Exports schemaDocumentDigest, SchemaTransferPage; uses 1 lifecycle effect(s); calls importStatus, exportDocument.
- `ui/admin/src/pages/service-tokens-page.test.tsx` — Tests lists, issues, reveals once, and revokes a service token; contains 10 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/pages/service-tokens-page.tsx` — Exports ServiceTokensPage; uses 1 lifecycle effect(s).
- `ui/admin/src/pages/settings-page.test.tsx` — Tests saves log capture controls and backup schedule as one revision; contains 8 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/pages/settings-page.tsx` — Exports SettingsPage; uses 2 lifecycle effect(s); creates 2 AbortController(s); calls get, ipAllowlist, update, setIPAllowlist.
- `ui/admin/src/pages/setup-page.test.tsx` — Tests reaches first-run setup and conceals the token until it is revealed; contains 32 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/pages/setup-page.tsx` — Exports SetupPage; uses 2 lifecycle effect(s); creates 1 AbortController(s).
- `ui/admin/src/pages/sql-console-page.test.tsx` — Tests starts read-only and retains exact tagged values instead of coercing them to JavaScript numbers; contains 44 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/pages/sql-console-page.tsx` — Exports SQLConsolePage; uses 3 lifecycle effect(s); creates 1 AbortController(s); calls history, execution, submit.
- `ui/admin/src/pages/storage-settings-page.test.tsx` — Tests preserves an omitted secret, warns on destination change, and tests only saved settings; contains 35 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/pages/storage-settings-page.tsx` — Exports StorageSettingsPage; uses 2 lifecycle effect(s); creates 2 AbortController(s); calls kind, administrator.
- `ui/admin/src/pages/system-page.test.tsx` — Tests renders the operational status the backend reports and nothing else; contains 52 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/pages/system-page.tsx` — Exports SystemPage; uses 1 lifecycle effect(s); creates 1 AbortController(s).
- `ui/admin/src/pages/users-page.test.tsx` — Tests lists bounded users and deactivates only after confirmation; contains 12 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/pages/users-page.tsx` — Exports UsersPage; uses 1 lifecycle effect(s); creates 2 AbortController(s); calls token, expiresAt.
- `ui/admin/src/pages/view-definition-editor.test.tsx` — Tests locks an existing SQL view to SQL mode while allowing query edits; contains 3 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/pages/view-definition-editor.tsx` — Exports ViewDefinitionEditor.
- `ui/admin/src/pages/view-sample-preview.tsx` — Exports ViewSamplePreview; calls sampleView.
- `ui/admin/src/relation/relation-picker.test.tsx` — Tests searches only when asked and sends one escaped, indexed lookup; contains 54 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/relation/relation-picker.ts` — Exports RelationSelection, ActiveStep, RelationPicker; uses 3 lifecycle effect(s); creates 4 AbortController(s); calls list, create, get.
- `ui/admin/src/relation/relation-query.test.ts` — Tests prefers presentable text and excludes hidden candidates; contains 25 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/relation/relation-query.ts` — Exports RelationCandidate, RelationTargetPlan, RelationTargetSearch.
- `ui/admin/src/relation/relation-target-picker.tsx` — Exports RelationTargetPicker.
- `ui/admin/src/routing/admin-link.test.tsx` — Tests addresses $kind with a href that parses back to the route; contains 6 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/routing/admin-link.tsx` — Builds typed-route href values and intercepts only unmodified primary clicks; modified/non-primary clicks retain browser new-tab/window and copy-link behavior.
- `ui/admin/src/routing/admin-location.test.tsx` — Tests round-trips $kind through its path; contains 39 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/routing/admin-location.ts` — Exports AdminRoute, AdminHistory, parseAdminRoute; uses 1 lifecycle effect(s).
- `ui/admin/src/routing/unsaved-draft.test.tsx` — Tests asks only while a resource still holds work the server has not seen; contains 24 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/routing/unsaved-draft.tsx` — Exports draftLedger, UnsavedDrafts, useUnsavedDraft; uses 3 lifecycle effect(s).
- `ui/admin/src/styles.css` — Defines responsive administration layout, focus and listbox interaction styling; CSS has no executable behavior or external resource loading.
- `ui/admin/src/test/backend-script.ts` — Exports Fault, Step, deferredStep.
- `ui/admin/src/test/fixtures.ts` — Exports activeSessionExpiresAt.
- `ui/admin/src/test/harness.tsx` — Exports administrator, activeSessionExpiresAt, signedInScript.
- `ui/admin/src/test/http-harness.ts` — Exports Wire, wireResponse, errorBody.
- `ui/admin/src/test/memory-backend.ts` — Exports memoryBackend.
- `ui/admin/src/test/memory-history.ts` — Exports MemoryHistory, memoryHistory.
- `ui/admin/src/test/setup.ts` — Read all 4 lines; this file participates in the administrator UI's typed rendering, route, backend, test, or build contract.
- `ui/admin/src/workspace/advanced-field-codec.test.ts` — Tests keeps HTML as text and measures its UTF-8 byte limit; contains 20 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/workspace/record-codec.test.ts` — Tests encodes every field type exactly, without rounding a decimal string; contains 36 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/workspace/record-codec.ts` — Exports FieldState, Draft, canonicalRelationID.
- `ui/admin/src/workspace/record-productivity.test.ts` — Tests persists valid columns while keeping id visible and ignoring removed fields; contains 16 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/workspace/record-productivity.ts` — Exports RecordScope, readColumns, writeColumns; calls v1.
- `ui/admin/src/workspace/record-workspace.test.tsx` — Tests carries the applied filter and sort into every page including the next cursor; contains 96 explicit expect assertions covering rendered state, emitted request input, route movement, or cancellation behavior.
- `ui/admin/src/workspace/record-workspace.ts` — Exports RecordList, useRecordList, RecordEditor; uses 5 lifecycle effect(s); creates 7 AbortController(s); calls catalog, list, remove, get.
- `ui/admin/tsconfig.app.json` — Enables strict ES2022 DOM browser compilation with bundler resolution, noEmit and unused checks for src.
- `ui/admin/tsconfig.json` — Uses project references so the root delegates browser options to tsconfig.app.json and Vite-node options to its companion config.
- `ui/admin/vite.config.ts` — Configures the React Vite build that writes the embedded dist asset names consumed by the Go handler.
